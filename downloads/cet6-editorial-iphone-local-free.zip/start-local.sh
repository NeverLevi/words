#!/bin/sh
cd "$(dirname "$0")"
echo "六级编辑部正在运行：http://localhost:8000/index.html"
echo "首次打开并等待词库加载完成后，即可添加到 iPhone 主屏幕。"
python3 -m http.server 8000 --bind 127.0.0.1
