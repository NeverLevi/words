const CACHE = "cet6-editorial-08fa336a153d";
const APP_FILES = [
  "./",
  "./apple-touch-icon.png",
  "./assets/index-AUKeDYNA.js",
  "./assets/index-D-utOJvo.css",
  "./icon-192.png",
  "./icon-512.png",
  "./icon.svg",
  "./index.html",
  "./manifest.webmanifest",
  "./vocabulary/import-report.json",
  "./vocabulary/manifest.json",
  "./vocabulary/words-0001-0500.json",
  "./vocabulary/words-0501-1000.json",
  "./vocabulary/words-1001-1500.json",
  "./vocabulary/words-1501-2000.json",
  "./vocabulary/words-2001-2500.json",
  "./vocabulary/words-2501-3000.json",
  "./vocabulary/words-3001-3500.json",
  "./vocabulary/words-3501-4000.json",
  "./vocabulary/words-4001-4500.json",
  "./vocabulary/words-4501-5000.json",
  "./vocabulary/words-5001-5500.json",
  "./vocabulary/words-5501-6000.json",
  "./vocabulary/words-6001-6500.json",
  "./vocabulary/words-6501-7000.json",
  "./vocabulary/words-7001-7500.json",
  "./vocabulary/words-7501-7803.json"
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(APP_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(Promise.all([
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))),
    self.clients.claim(),
  ]));
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request)));
});
